package app.keyvault.manager

import android.os.Bundle
import com.getcapacitor.BridgeActivity

class MainActivity : BridgeActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        registerPlugin(ShakePlugin::class.java)
        super.onCreate(savedInstanceState)
    }
}
