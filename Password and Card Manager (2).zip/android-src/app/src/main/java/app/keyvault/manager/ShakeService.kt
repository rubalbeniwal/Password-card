package app.keyvault.manager

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.hardware.*
import android.os.*
import android.view.*
import android.webkit.*
import androidx.core.app.NotificationCompat

class ShakeService : Service(), SensorEventListener {

    private lateinit var sensorManager: SensorManager
    private var accelerometer: Sensor? = null
    private var windowManager: WindowManager? = null
    private var overlayView: View? = null

    private var lastX = 0f
    private var lastY = 0f
    private var lastZ = 0f
    private var lastTime = 0L
    private var cooldown = false

    companion object {
        const val CHANNEL_ID = "keyvault_shake"
        const val NOTIF_ID = 1001
        var isRunning = false
    }

    override fun onCreate() {
        super.onCreate()
        isRunning = true
        sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        sensorManager.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_UI)
        startForegroundNotification()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return START_STICKY
    }

    override fun onSensorChanged(event: SensorEvent) {
        if (event.sensor.type != Sensor.TYPE_ACCELEROMETER) return
        val now = System.currentTimeMillis()
        if (now - lastTime < 100) return

        val dx = Math.abs(event.values[0] - lastX)
        val dy = Math.abs(event.values[1] - lastY)
        val dz = Math.abs(event.values[2] - lastZ)
        lastX = event.values[0]
        lastY = event.values[1]
        lastZ = event.values[2]
        lastTime = now

        if (dx + dy + dz > 28f && !cooldown) {
            cooldown = true
            Handler(Looper.getMainLooper()).postDelayed({ cooldown = false }, 1500)
            Handler(Looper.getMainLooper()).post { showOverlay() }
        }
    }

    private fun showOverlay() {
        if (overlayView != null) return
        if (!android.provider.Settings.canDrawOverlays(this)) return

        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        windowManager = wm

        val webView = WebView(this).apply {
            setBackgroundColor(Color.TRANSPARENT)
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = true
            settings.databaseEnabled = true

            addJavascriptInterface(object : Any() {
                @JavascriptInterface
                fun dismiss() {
                    Handler(Looper.getMainLooper()).post { removeOverlay() }
                }
                @JavascriptInterface
                fun isOverlay(): Boolean = true
            }, "NativeBridge")

            webViewClient = object : WebViewClient() {
                override fun onPageFinished(view: WebView?, url: String?) {
                    // Tell the web app it's running as overlay, trigger popup
                    view?.evaluateJavascript(
                        "window.__KEYVAULT_OVERLAY__ = true; window.dispatchEvent(new CustomEvent('keyvault-shake'));",
                        null
                    )
                }
            }
            loadUrl("http://localhost")
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else
                @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )

        overlayView = webView
        wm.addView(webView, params)
    }

    private fun removeOverlay() {
        overlayView?.let {
            windowManager?.removeView(it)
            overlayView = null
        }
    }

    private fun startForegroundNotification() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "KeyVault Shake Detector",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Listens for shake to trigger autofill"
                setShowBadge(false)
            }
            getSystemService(NotificationManager::class.java)
                .createNotificationChannel(channel)
        }

        val openIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("KeyVault")
            .setContentText("Shake to autofill")
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setOngoing(true)
            .setContentIntent(openIntent)
            .build()

        startForeground(NOTIF_ID, notification)
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        isRunning = false
        sensorManager.unregisterListener(this)
        removeOverlay()
    }
}
