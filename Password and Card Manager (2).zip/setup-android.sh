#!/bin/bash
set -e

PACKAGE_PATH="android/app/src/main/java/app/keyvault/manager"
MANIFEST="android/app/src/main/AndroidManifest.xml"

echo "📦 Building web app..."
npm run build

echo "📱 Adding Android platform..."
npx cap add android 2>/dev/null || true

echo "🔄 Syncing Capacitor..."
npx cap sync android

echo "📂 Copying native Kotlin files..."
mkdir -p "$PACKAGE_PATH"
cp android-src/app/src/main/java/app/keyvault/manager/ShakeService.kt "$PACKAGE_PATH/"
cp android-src/app/src/main/java/app/keyvault/manager/MainActivity.kt "$PACKAGE_PATH/"
cp android-src/app/src/main/java/app/keyvault/manager/BootReceiver.kt "$PACKAGE_PATH/"

echo "📝 Patching AndroidManifest.xml..."
# Add permissions before </manifest>
sed -i 's|</manifest>|    <uses-permission android:name="android.permission.SYSTEM_ALERT_WINDOW"/>\n    <uses-permission android:name="android.permission.FOREGROUND_SERVICE"/>\n    <uses-permission android:name="android.permission.FOREGROUND_SERVICE_SPECIAL_USE"/>\n    <uses-permission android:name="android.permission.RECEIVE_BOOT_COMPLETED"/>\n</manifest>|' "$MANIFEST"

# Add service and receiver before </application>
sed -i 's|</application>|        <service android:name=".ShakeService" android:foregroundServiceType="specialUse" android:exported="false" android:stopWithTask="false"><property android:name="android.app.PROPERTY_SPECIAL_USE_FGS_SUBTYPE" android:value="shakeDetector"/></service>\n        <receiver android:name=".BootReceiver" android:exported="true"><intent-filter><action android:name="android.intent.action.BOOT_COMPLETED"/></intent-filter></receiver>\n    </application>|' "$MANIFEST"

echo "✅ Done! Now open Android Studio:"
echo "   npx cap open android"
echo "   Then: Build → Build APK"
