import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'app.keyvault.manager',
  appName: 'KeyVault',
  webDir: 'dist',
  android: {
    backgroundColor: '#141218',
  },
};

export default config;
