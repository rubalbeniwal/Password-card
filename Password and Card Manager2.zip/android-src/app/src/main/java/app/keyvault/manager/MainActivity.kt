package app.keyvault.manager

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import com.getcapacitor.BridgeActivity

class MainActivity : BridgeActivity() {

    companion object {
        const val REQ_OVERLAY = 1001
        const val REQ_BATTERY = 1002
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        registerPlugin(ShakePlugin::class.java)
        super.onCreate(savedInstanceState)
        handlePermissions()
    }

    private fun handlePermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            try {
                val intent = Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
                startActivityForResult(intent, REQ_OVERLAY)
            } catch (e: Exception) {
                val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION)
                startActivityForResult(intent, REQ_OVERLAY)
            }
        } else {
            onOverlayGranted()
        }
    }

    private fun onOverlayGranted() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val pm = getSystemService(PowerManager::class.java)
            if (pm != null && !pm.isIgnoringBatteryOptimizations(packageName)) {
                try {
                    val intent = Intent(
                        Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                        Uri.parse("package:$packageName")
                    )
                    startActivityForResult(intent, REQ_BATTERY)
                    return
                } catch (e: Exception) {
                    startShakeService()
                    return
                }
            }
        }
        startShakeService()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            REQ_OVERLAY -> {
                if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(this)) {
                    onOverlayGranted()
                }
            }
            REQ_BATTERY -> startShakeService()
        }
    }

    override fun onResume() {
        super.onResume()
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(this)) {
            if (!ShakeService.isRunning) {
                startShakeService()
            }
        }
        bridge?.webView?.post {
            bridge.webView.evaluateJavascript(
                "window.__KEYVAULT_SERVICE_RUNNING__ = ${ShakeService.isRunning};", null
            )
        }
    }

    private fun startShakeService() {
        if (!ShakeService.isRunning) {
            val intent = Intent(this, ShakeService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(intent)
            } else {
                startService(intent)
            }
        }
    }
}