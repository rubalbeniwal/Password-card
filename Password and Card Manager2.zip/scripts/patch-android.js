#!/usr/bin/env node
// Patches the Capacitor-generated AndroidManifest.xml reliably

import { readFileSync, writeFileSync } from 'fs';

const MANIFEST = 'android/app/src/main/AndroidManifest.xml';

let xml = readFileSync(MANIFEST, 'utf8');

// ── Permissions to inject before </manifest> ──
const permissions = [
  'android.permission.SYSTEM_ALERT_WINDOW',
  'android.permission.FOREGROUND_SERVICE',
  'android.permission.FOREGROUND_SERVICE_SPECIAL_USE',
  'android.permission.RECEIVE_BOOT_COMPLETED',
  'android.permission.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS',
];

permissions.forEach(perm => {
  const tag = `<uses-permission android:name="${perm}"/>`;
  if (!xml.includes(perm)) {
    xml = xml.replace('</manifest>', `    ${tag}\n</manifest>`);
    console.log(`✅ Added permission: ${perm}`);
  } else {
    console.log(`⏭  Already present: ${perm}`);
  }
});

// ── Service declaration ──
const service = `
        <service
            android:name=".ShakeService"
            android:foregroundServiceType="specialUse"
            android:exported="false"
            android:stopWithTask="false">
            <property
                android:name="android.app.PROPERTY_SPECIAL_USE_FGS_SUBTYPE"
                android:value="shakeDetector"/>
        </service>`;

if (!xml.includes('ShakeService')) {
  xml = xml.replace('</application>', `${service}\n    </application>`);
  console.log('✅ Added ShakeService');
} else {
  console.log('⏭  ShakeService already present');
}

// ── BootReceiver ──
const receiver = `
        <receiver
            android:name=".BootReceiver"
            android:exported="true">
            <intent-filter>
                <action android:name="android.intent.action.BOOT_COMPLETED"/>
            </intent-filter>
        </receiver>`;

if (!xml.includes('BootReceiver')) {
  xml = xml.replace('</application>', `${receiver}\n    </application>`);
  console.log('✅ Added BootReceiver');
} else {
  console.log('⏭  BootReceiver already present');
}

writeFileSync(MANIFEST, xml, 'utf8');
console.log('\n📄 Final AndroidManifest.xml:\n');
console.log(xml);
