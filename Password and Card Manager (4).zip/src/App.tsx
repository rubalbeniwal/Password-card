import { useState, useCallback, useRef, useEffect } from "react";
import ShakePlugin from "./ShakePlugin";

// ── Types ─────────────────────────────────────────────────────────────────────
type Screen =
  | "idle"
  | "pill-options"
  | "cards-list"
  | "passwords-list"
  | "fingerprint"
  | "card-reveal"
  | "password-reveal";

interface CreditCard {
  id: string;
  name: string;
  number: string;
  expiry: string;
  cvv: string;
  holder: string;
  type: "visa" | "mastercard" | "amex" | "rupay";
  gradient: string;
  accentColor: string;
  lightText: boolean;
}

interface Password {
  id: string;
  site: string;
  username: string;
  realPassword: string;
  icon: string;
  color: string;
}

// ── M3 Tokens ─────────────────────────────────────────────────────────────────
const M3 = {
  bg:                      "#141218",
  surface:                 "#141218",
  surfaceContainer:        "#211F26",
  surfaceContainerHigh:    "#2B2930",
  surfaceContainerHighest: "#36343B",
  primary:                 "#D0BCFF",
  onPrimary:               "#381E72",
  primaryContainer:        "#4F378B",
  onPrimaryContainer:      "#EADDFF",
  secondary:               "#CCC2DC",
  secondaryContainer:      "#4A4458",
  onSecondaryContainer:    "#E8DEF8",
  tertiary:                "#EFB8C8",
  outline:                 "#938F99",
  outlineVariant:          "#49454F",
  onSurface:               "#E6E1E5",
  onSurfaceVariant:        "#CAC4D0",
  error:                   "#F2B8B5",
  success:                 "#6EE7B7",
};

// ── Seed data ─────────────────────────────────────────────────────────────────
const INIT_CARDS: CreditCard[] = [
  {
    id: "1",
    name: "Chase Sapphire Reserve",
    number: "4532 1234 5678 9012",
    expiry: "09/27",
    cvv: "456",
    holder: "Alex Morgan",
    type: "visa",
    gradient: "linear-gradient(135deg, #0f0c29 0%, #1a1a4e 40%, #24243e 100%)",
    accentColor: "#9ba8f0",
    lightText: false,
  },
  {
    id: "2",
    name: "Amex Platinum",
    number: "3782 822463 10005",
    expiry: "12/26",
    cvv: "1234",
    holder: "Alex Morgan",
    type: "amex",
    gradient: "linear-gradient(135deg, #1a1a1a 0%, #2d2d2d 50%, #1a1a1a 100%)",
    accentColor: "#c8a84b",
    lightText: false,
  },
  {
    id: "3",
    name: "Google One Card",
    number: "4111 1111 1111 1111",
    expiry: "03/28",
    cvv: "737",
    holder: "Alex Morgan",
    type: "mastercard",
    gradient: "linear-gradient(135deg, #e8e8e8 0%, #f5f5f5 50%, #e0e0e0 100%)",
    accentColor: "#333333",
    lightText: true,
  },
];

const INIT_PASSWORDS: Password[] = [
  { id: "1", site: "Google", username: "alex.morgan@gmail.com", realPassword: "G00gl3#S3cur3!", icon: "G", color: "#EA4335" },
  { id: "2", site: "Samsung", username: "alex@samsung.com", realPassword: "S@ms!ngGalaxy24", icon: "S", color: "#1428A0" },
  { id: "3", site: "GitHub", username: "alexmorgan", realPassword: "Gh1tb#0cean99!", icon: "⌥", color: "#6E5494" },
  { id: "4", site: "Netflix", username: "alex@gmail.com", realPassword: "N3tfl!xCh1ll22", icon: "N", color: "#E50914" },
];

const CARD_GRADIENTS = [
  // Deep navy (classic premium)
  { gradient: "linear-gradient(135deg, #0f0c29 0%, #1a1a4e 40%, #24243e 100%)", accent: "#9ba8f0", light: false },
  // Matte black / Amex Centurion
  { gradient: "linear-gradient(135deg, #1a1a1a 0%, #2d2d2d 50%, #1a1a1a 100%)", accent: "#c8a84b", light: false },
  // Forest green (HDFC Millennia)
  { gradient: "linear-gradient(135deg, #0d3b2e 0%, #1a5c46 60%, #0d3b2e 100%)", accent: "#6ee7b7", light: false },
  // Deep plum
  { gradient: "linear-gradient(135deg, #3b0d2e 0%, #6b1a50 60%, #3b0d2e 100%)", accent: "#f0a0d0", light: false },
  // Royal indigo
  { gradient: "linear-gradient(135deg, #1a1a3e 0%, #2d2d6b 50%, #1a1a3e 100%)", accent: "#a0b0f0", light: false },
  // Amex Gold warm
  { gradient: "linear-gradient(135deg, #7a5a0a 0%, #c8960a 40%, #e8b820 65%, #a07010 100%)", accent: "#fde68a", light: false },
  // Rose gold metallic
  { gradient: "linear-gradient(135deg, #5c2a2a 0%, #b5626c 40%, #e8a0aa 65%, #c87880 100%)", accent: "#fecdd3", light: false },
  // Titanium / Axis Magnus
  { gradient: "linear-gradient(135deg, #1c1c1c 0%, #3a3a3a 35%, #5a5a5a 60%, #2a2a2a 100%)", accent: "#d4d4d4", light: false },
  // Coral red (Capital One Quicksilver)
  { gradient: "linear-gradient(135deg, #7a1a0a 0%, #c0392b 50%, #e74c3c 100%)", accent: "#fca5a5", light: false },
  // Ocean teal (HDFC Regalia)
  { gradient: "linear-gradient(135deg, #0a3a4a 0%, #0e7490 50%, #0a5a6e 100%)", accent: "#67e8f9", light: false },
  // Deep crimson (Kotak 811)
  { gradient: "linear-gradient(135deg, #5a0a0a 0%, #991b1b 50%, #7f1d1d 100%)", accent: "#fca5a5", light: false },
  // Midnight copper (Chase Sapphire)
  { gradient: "linear-gradient(135deg, #0a1628 0%, #1e3a5f 45%, #0d2240 100%)", accent: "#b87333", light: false },
  // SBI navy blue
  { gradient: "linear-gradient(135deg, #001f5b 0%, #003399 50%, #001f5b 100%)", accent: "#7eb3ff", light: false },
  // RuPay green-orange
  { gradient: "linear-gradient(135deg, #0a3a1a 0%, #1a6b2a 45%, #e85c00 100%)", accent: "#fbbf24", light: false },
  // Champagne cream (light card)
  { gradient: "linear-gradient(135deg, #f5f0e8 0%, #ede5d4 40%, #d4c9b0 100%)", accent: "#78350f", light: true },
  // Matte slate
  { gradient: "linear-gradient(135deg, #1e2a38 0%, #2d3f52 50%, #1e2a38 100%)", accent: "#94b4d4", light: false },
  // ICICI dark orange
  { gradient: "linear-gradient(135deg, #4a1a00 0%, #b45309 45%, #92400e 100%)", accent: "#fcd34d", light: false },
  // Midnight emerald
  { gradient: "linear-gradient(135deg, #022c22 0%, #064e3b 45%, #065f46 100%)", accent: "#34d399", light: false },
  // Lavender purple (Yes Bank)
  { gradient: "linear-gradient(135deg, #2e1065 0%, #5b21b6 50%, #4c1d95 100%)", accent: "#c4b5fd", light: false },
  // Warm graphite
  { gradient: "linear-gradient(135deg, #292524 0%, #44403c 50%, #292524 100%)", accent: "#d6d3d1", light: false },
];

function detectCardType(num: string): CreditCard["type"] {
  const n = num.replace(/\s/g, "");
  if (n.startsWith("4")) return "visa";
  if (n.startsWith("34") || n.startsWith("37")) return "amex";
  if (n.startsWith("60") || n.startsWith("65") || n.startsWith("81") || n.startsWith("82")) return "rupay";
  return "mastercard";
}

function formatCardNumber(val: string, type: CreditCard["type"]) {
  const digits = val.replace(/\D/g, "").slice(0, type === "amex" ? 15 : 16);
  if (type === "amex") {
    return digits.replace(/(\d{4})(\d{6})(\d{5})/, "$1 $2 $3")
      .replace(/(\d{4})(\d{1,6})/, "$1 $2")
      .replace(/(\d{4} \d{6})(\d{1,5})/, "$1 $2");
  }
  return digits.replace(/(\d{4})(?=\d)/g, "$1 ").trim();
}

function formatExpiry(val: string) {
  const digits = val.replace(/\D/g, "").slice(0, 4);
  if (digits.length >= 3) return digits.slice(0, 2) + "/" + digits.slice(2);
  return digits;
}

// ── Card brand intelligence ───────────────────────────────────────────────────
interface CardStyle {
  gradient: string;
  accent: string;
  light: boolean;
  matched: string;
}

const BRAND_STYLES: { keywords: string[]; style: CardStyle }[] = [
  // Chase
  { keywords: ["chase sapphire reserve"],   style: { gradient: "linear-gradient(135deg, #0a1628 0%, #0d2347 45%, #15387a 100%)", accent: "#7b9ee8", light: false, matched: "Chase Sapphire Reserve" } },
  { keywords: ["chase sapphire preferred"], style: { gradient: "linear-gradient(135deg, #0d2347 0%, #1a3a6b 50%, #1e4d8c 100%)", accent: "#93b4f0", light: false, matched: "Chase Sapphire Preferred" } },
  { keywords: ["chase freedom"],            style: { gradient: "linear-gradient(135deg, #1a237e 0%, #283593 50%, #3949ab 100%)", accent: "#82b1ff", light: false, matched: "Chase Freedom" } },
  // Amex
  { keywords: ["amex platinum","american express platinum"], style: { gradient: "linear-gradient(135deg, #1a1a1a 0%, #2d2d2d 40%, #3a3a3a 70%, #1a1a1a 100%)", accent: "#d4af37", light: false, matched: "Amex Platinum" } },
  { keywords: ["amex gold","american express gold"],         style: { gradient: "linear-gradient(135deg, #b8860b 0%, #d4a017 40%, #c8940f 70%, #a07010 100%)", accent: "#fff3b0", light: false, matched: "Amex Gold" } },
  { keywords: ["amex blue","american express blue"],        style: { gradient: "linear-gradient(135deg, #0057b8 0%, #0072ce 50%, #0091d5 100%)", accent: "#7ecfff", light: false, matched: "Amex Blue" } },
  { keywords: ["amex","american express"],                  style: { gradient: "linear-gradient(135deg, #1c1c2e 0%, #2a2a40 50%, #1c1c2e 100%)", accent: "#c8a84b", light: false, matched: "American Express" } },
  // Apple
  { keywords: ["apple card","apple"],                       style: { gradient: "linear-gradient(135deg, #e8e8e8 0%, #f7f7f7 50%, #efefef 100%)", accent: "#1c1c1e", light: true,  matched: "Apple Card" } },
  // Google
  { keywords: ["google"],                                   style: { gradient: "linear-gradient(135deg, #1a73e8 0%, #0d47a1 50%, #1565c0 100%)", accent: "#8ab4f8", light: false, matched: "Google Card" } },
  // Samsung
  { keywords: ["samsung"],                                  style: { gradient: "linear-gradient(135deg, #1428a0 0%, #1e3a8a 50%, #0f2563 100%)", accent: "#93c5fd", light: false, matched: "Samsung Card" } },
  // Citi
  { keywords: ["citi prestige"],                            style: { gradient: "linear-gradient(135deg, #0a0a0a 0%, #1a1a1a 40%, #2a2a2a 100%)", accent: "#c0b090", light: false, matched: "Citi Prestige" } },
  { keywords: ["citi double cash","citi"],                  style: { gradient: "linear-gradient(135deg, #003087 0%, #0041a0 50%, #0052cc 100%)", accent: "#a0c4ff", light: false, matched: "Citi Card" } },
  // Capital One
  { keywords: ["capital one venture"],                      style: { gradient: "linear-gradient(135deg, #a00000 0%, #cc0000 40%, #e00000 80%, #a00000 100%)", accent: "#ffb3b3", light: false, matched: "Capital One Venture" } },
  { keywords: ["capital one"],                              style: { gradient: "linear-gradient(135deg, #8b0000 0%, #b00000 50%, #8b0000 100%)", accent: "#ffaaaa", light: false, matched: "Capital One" } },
  // Discover
  { keywords: ["discover"],                                 style: { gradient: "linear-gradient(135deg, #ffffff 0%, #f5f5f5 50%, #ebebeb 100%)", accent: "#e55c00", light: true,  matched: "Discover" } },
  // Wells Fargo
  { keywords: ["wells fargo"],                              style: { gradient: "linear-gradient(135deg, #cc0000 0%, #a30000 50%, #7a0000 100%)", accent: "#ffd700", light: false, matched: "Wells Fargo" } },
  // Bank of America
  { keywords: ["bank of america","bofa"],                   style: { gradient: "linear-gradient(135deg, #012169 0%, #c8102e 60%, #012169 100%)", accent: "#e8b84b", light: false, matched: "Bank of America" } },
  // HSBC
  { keywords: ["hsbc"],                                     style: { gradient: "linear-gradient(135deg, #db0011 0%, #9b000c 50%, #db0011 100%)", accent: "#ffffff", light: false, matched: "HSBC" } },
  // Barclays
  { keywords: ["barclays"],                                 style: { gradient: "linear-gradient(135deg, #00aeef 0%, #0072bc 50%, #003087 100%)", accent: "#b3e5fc", light: false, matched: "Barclays" } },
  // HDFC
  { keywords: ["hdfc"],                                     style: { gradient: "linear-gradient(135deg, #004c8c 0%, #003a6e 50%, #002952 100%)", accent: "#ef3e42", light: false, matched: "HDFC Bank" } },
  // ICICI
  { keywords: ["icici"],                                    style: { gradient: "linear-gradient(135deg, #f37021 0%, #c0510e 50%, #8a3a0a 100%)", accent: "#ffe0b2", light: false, matched: "ICICI Bank" } },
  // SBI
  { keywords: ["sbi","state bank"],                         style: { gradient: "linear-gradient(135deg, #2e3192 0%, #1b1464 50%, #0e0b3d 100%)", accent: "#7ec8e3", light: false, matched: "SBI" } },
  // Kotak
  { keywords: ["kotak"],                                    style: { gradient: "linear-gradient(135deg, #ed1c24 0%, #a3000a 50%, #6d0007 100%)", accent: "#ffffff", light: false, matched: "Kotak Bank" } },
  // Mastercard generic
  { keywords: ["mastercard","master card"],                 style: { gradient: "linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%)", accent: "#f79e1b", light: false, matched: "Mastercard" } },
  // Visa generic
  { keywords: ["visa"],                                     style: { gradient: "linear-gradient(135deg, #1a1f71 0%, #1e2d99 50%, #2136cc 100%)", accent: "#f0c040", light: false, matched: "Visa" } },
];

function detectCardStyle(name: string): CardStyle | null {
  const lower = name.toLowerCase().trim();
  if (!lower) return null;
  for (const entry of BRAND_STYLES) {
    if (entry.keywords.some(k => lower.includes(k))) return entry.style;
  }
  return null;
}

// ── Ripple hook ───────────────────────────────────────────────────────────────
function useRipple(color = "rgba(208,188,255,0.28)") {
  const [ripples, setRipples] = useState<{ id: number; x: number; y: number; d: number }[]>([]);

  const onPointerDown = (e: React.PointerEvent<HTMLElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const d = Math.max(rect.width, rect.height) * 2.2;
    const x = e.clientX - rect.left - d / 2;
    const y = e.clientY - rect.top - d / 2;
    const id = Date.now() + Math.random();
    setRipples(r => [...r, { id, x, y, d }]);
    setTimeout(() => setRipples(r => r.filter(rp => rp.id !== id)), 600);
  };

  const Ripples = () => (
    <>
      {ripples.map(rp => (
        <span
          key={rp.id}
          className="m3-ripple"
          style={{ left: rp.x, top: rp.y, width: rp.d, height: rp.d, background: color }}
        />
      ))}
    </>
  );

  return { onPointerDown, Ripples };
}

// ── Android status bar ────────────────────────────────────────────────────────
function StatusBar() {
  const [time, setTime] = useState(() => {
    const d = new Date();
    return `${d.getHours().toString().padStart(2, "0")}:${d.getMinutes().toString().padStart(2, "0")}`;
  });

  useEffect(() => {
    const t = setInterval(() => {
      const d = new Date();
      setTime(`${d.getHours().toString().padStart(2, "0")}:${d.getMinutes().toString().padStart(2, "0")}`);
    }, 30000);
    return () => clearInterval(t);
  }, []);

  return (
    <div style={{
      height: "calc(28px + env(safe-area-inset-top))",
      paddingTop: "env(safe-area-inset-top)",
      display: "flex", alignItems: "center",
      justifyContent: "space-between", padding: "env(safe-area-inset-top) 18px 0",
      flexShrink: 0, background: M3.bg,
    }}>
      <span style={{ fontSize: 13, fontWeight: 500, color: M3.onSurface, letterSpacing: "0.01em" }}>{time}</span>
      <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
        {/* Signal bars */}
        <svg width="16" height="12" viewBox="0 0 16 12" fill="none">
          <rect x="0" y="8" width="3" height="4" rx="1" fill={M3.onSurface}/>
          <rect x="4.5" y="5" width="3" height="7" rx="1" fill={M3.onSurface}/>
          <rect x="9" y="2" width="3" height="10" rx="1" fill={M3.onSurface}/>
          <rect x="13.5" y="0" width="2.5" height="12" rx="1" fill={M3.onSurface} opacity="0.35"/>
        </svg>
        {/* WiFi */}
        <svg width="16" height="12" viewBox="0 0 16 12" fill="none">
          <path d="M8 9.5a1 1 0 1 0 0 2 1 1 0 0 0 0-2Z" fill={M3.onSurface}/>
          <path d="M5.2 7.3C5.9 6.5 6.9 6 8 6s2.1.5 2.8 1.3" stroke={M3.onSurface} strokeWidth="1.4" strokeLinecap="round"/>
          <path d="M2.8 5C4.1 3.7 5.9 3 8 3s3.9.7 5.2 2" stroke={M3.onSurface} strokeWidth="1.4" strokeLinecap="round"/>
          <path d="M0.5 2.6C2.3.9 5 0 8 0s5.7.9 7.5 2.6" stroke={M3.onSurface} strokeWidth="1.4" strokeLinecap="round" opacity="0.4"/>
        </svg>
        {/* Battery */}
        <svg width="22" height="12" viewBox="0 0 22 12" fill="none">
          <rect x="0.5" y="0.5" width="18" height="11" rx="2.5" stroke={M3.onSurface} strokeWidth="1"/>
          <rect x="19" y="3.5" width="2.5" height="5" rx="1.2" fill={M3.onSurface} opacity="0.5"/>
          <rect x="2" y="2" width="13" height="8" rx="1.5" fill={M3.onSurface}/>
        </svg>
      </div>
    </div>
  );
}

// ── Gesture navigation bar ────────────────────────────────────────────────────
function GestureBar() {
  return (
    <div style={{ height: "calc(20px + env(safe-area-inset-bottom))", paddingBottom: "env(safe-area-inset-bottom)", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
      <div style={{ width: 134, height: 5, borderRadius: 100, background: M3.onSurface, opacity: 0.28 }} />
    </div>
  );
}

// ── Bottom navigation ─────────────────────────────────────────────────────────
function BottomNav({ active, onChange }: { active: "passwords" | "cards" | "settings"; onChange: (t: "passwords" | "cards" | "settings") => void }) {
  const tabs = [
    {
      id: "passwords" as const,
      label: "Passwords",
      icon: (active: boolean) => (
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
          <path d="M12 17c1.1 0 2-.9 2-2s-.9-2-2-2-2 .9-2 2 .9 2 2 2Z" fill={active ? M3.onPrimary : M3.onSurfaceVariant}/>
          <path d="M17 9h-1V7c0-2.2-1.8-4-4-4S8 4.8 8 7v2H7c-1.1 0-2 .9-2 2v10c0 1.1.9 2 2 2h10c1.1 0 2-.9 2-2V11c0-1.1-.9-2-2-2Zm-5-4c1.1 0 2 .9 2 2v2h-4V7c0-1.1.9-2 2-2Z" fill={active ? M3.onPrimary : M3.onSurfaceVariant}/>
        </svg>
      ),
    },
    {
      id: "cards" as const,
      label: "Cards",
      icon: (active: boolean) => (
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
          <path d="M20 4H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2ZM4 8h16v2H4V8Zm0 10v-6h16v6H4Z" fill={active ? M3.onPrimary : M3.onSurfaceVariant}/>
          <path d="M6 16h4v2H6z" fill={active ? M3.onPrimary : M3.onSurfaceVariant}/>
        </svg>
      ),
    },
    {
      id: "settings" as const,
      label: "Settings",
      icon: (active: boolean) => (
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
          <path d="M19.14 12.94c.04-.3.06-.61.06-.94 0-.32-.02-.64-.07-.94l2.03-1.58c.18-.14.23-.41.12-.61l-1.92-3.32c-.12-.22-.37-.29-.59-.22l-2.39.96c-.5-.38-1.03-.7-1.62-.94l-.36-2.54c-.04-.24-.24-.41-.48-.41h-3.84c-.24 0-.43.17-.47.41l-.36 2.54c-.59.24-1.13.57-1.62.94l-2.39-.96c-.22-.08-.47 0-.59.22L2.74 8.87c-.12.21-.08.47.12.61l2.03 1.58c-.05.3-.09.63-.09.94s.02.64.07.94l-2.03 1.58c-.18.14-.23.41-.12.61l1.92 3.32c.12.22.37.29.59.22l2.39-.96c.5.38 1.03.7 1.62.94l.36 2.54c.05.24.24.41.48.41h3.84c.24 0 .44-.17.47-.41l.36-2.54c.59-.24 1.13-.56 1.62-.94l2.39.96c.22.08.47 0 .59-.22l1.92-3.32c.12-.22.07-.47-.12-.61l-2.01-1.58ZM12 15.6c-1.98 0-3.6-1.62-3.6-3.6s1.62-3.6 3.6-3.6 3.6 1.62 3.6 3.6-1.62 3.6-3.6 3.6Z" fill={active ? M3.onPrimary : M3.onSurfaceVariant}/>
        </svg>
      ),
    },
  ];

  return (
    <div style={{
      display: "flex", background: M3.surfaceContainer,
      borderTop: `1px solid ${M3.outlineVariant}22`,
    }}>
      {tabs.map(tab => {
        const isActive = active === tab.id;
        const { onPointerDown, Ripples } = useRipple("rgba(208,188,255,0.2)");
        return (
          <button
            key={tab.id}
            onPointerDown={onPointerDown}
            onClick={() => onChange(tab.id)}
            className="ripple-root"
            style={{
              flex: 1, display: "flex", flexDirection: "column", alignItems: "center",
              gap: 4, padding: "12px 4px 8px", background: "none", border: "none",
              cursor: "pointer", position: "relative", overflow: "hidden",
            }}
          >
            <Ripples />
            <div style={{
              display: "flex", alignItems: "center", justifyContent: "center",
              width: 64, height: 32, borderRadius: 100,
              background: isActive ? M3.primaryContainer : "transparent",
              transition: "background 300ms cubic-bezier(0.2,0,0,1)",
            }}>
              {tab.icon(isActive)}
            </div>
            <span style={{
              fontSize: 12, fontWeight: isActive ? 500 : 400,
              color: isActive ? M3.primary : M3.onSurfaceVariant,
              transition: "color 200ms ease",
            }}>
              {tab.label}
            </span>
          </button>
        );
      })}
    </div>
  );
}

// ── Top Overlay (show-over-apps) ─────────────────────────────────────────────
function TopOverlay({
  open, onDismiss, onBack, children, label,
}: {
  open: boolean; onDismiss: () => void; onBack?: () => void; children: React.ReactNode; label?: string;
}) {
  const [mounted, setMounted] = useState(false);
  const [exiting, setExiting] = useState(false);

  useEffect(() => {
    if (open) { setMounted(true); setExiting(false); }
    else if (mounted) {
      setExiting(true);
      const t = setTimeout(() => setMounted(false), 260);
      return () => clearTimeout(t);
    }
  }, [open]);

  if (!mounted) return null;

  return (
    <div style={{ position: "absolute", inset: 0, zIndex: 40 }}>
      {/* Scrim — tap to dismiss */}
      <div
        onClick={onDismiss}
        className={exiting ? "scrim-exit" : "scrim-enter"}
        style={{ position: "absolute", inset: 0, background: "rgba(0,0,0,0.44)" }}
      />
      {/* Floating card from top — sits below status bar + camera cutout */}
      <div
        className={exiting ? "overlay-exit" : "overlay-enter"}
        style={{
          position: "absolute",
          top: 60,
          left: 12,
          right: 12,
          background: "rgba(28, 26, 34, 0.72)",
          backdropFilter: "blur(40px) saturate(180%)",
          WebkitBackdropFilter: "blur(40px) saturate(180%)",
          borderRadius: 28,
          overflow: "hidden",
          border: "1px solid rgba(255,255,255,0.10)",
          boxShadow: "0 12px 48px rgba(0,0,0,0.6), 0 2px 8px rgba(0,0,0,0.4), 0 0 0 0.5px rgba(255,255,255,0.06) inset",
        }}
      >
        {/* Header row */}
        {label && (
          <div style={{
            padding: "14px 16px 10px",
            display: "flex", alignItems: "center", gap: 8,
            borderBottom: "1px solid rgba(255,255,255,0.07)",
          }}>
            {/* Back OR close button */}
            <button
              onClick={onBack ?? onDismiss}
              style={{
                background: "rgba(255,255,255,0.09)", border: "1px solid rgba(255,255,255,0.07)",
                borderRadius: 100, width: 30, height: 30, cursor: "pointer",
                display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0,
              }}
            >
              {onBack ? (
                <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
                  <path d="M9 2L4 7l5 5" stroke={M3.onSurfaceVariant} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
              ) : (
                <svg width="13" height="13" viewBox="0 0 13 13" fill="none">
                  <path d="M1.5 1.5l10 10M11.5 1.5l-10 10" stroke={M3.onSurfaceVariant} strokeWidth="1.8" strokeLinecap="round"/>
                </svg>
              )}
            </button>
            <span style={{ fontSize: 15, fontWeight: 500, color: M3.onSurface, flex: 1 }}>{label}</span>
          </div>
        )}
        {children}
        {/* Swipe-up hint bar */}
        <div style={{ display: "flex", justifyContent: "center", padding: "8px 0 10px" }}>
          <div style={{ width: 32, height: 4, borderRadius: 100, background: M3.onSurfaceVariant, opacity: 0.25 }} />
        </div>
      </div>
    </div>
  );
}

// ── Card network logo ─────────────────────────────────────────────────────────
function CardLogo({ type, accent }: { type: CreditCard["type"]; accent: string }) {
  if (type === "visa") return (
    <span style={{ color: accent, fontWeight: 800, fontSize: 20, fontStyle: "italic", letterSpacing: -1, fontFamily: "Roboto, sans-serif" }}>VISA</span>
  );
  if (type === "amex") return (
    <div style={{ textAlign: "right" }}>
      <div style={{ color: accent, fontSize: 10, fontWeight: 700, letterSpacing: "0.18em" }}>AMERICAN</div>
      <div style={{ color: accent, fontSize: 10, fontWeight: 700, letterSpacing: "0.18em" }}>EXPRESS</div>
    </div>
  );
  if (type === "rupay") return (
    <svg width="22" height="22" viewBox="0 0 16 18" fill="none" xmlns="http://www.w3.org/2000/svg">
      <polygon points="0,1 8,9 0,17" fill="#f47920"/>
      <polygon points="5,1 13,9 5,17" fill="#3aaa35"/>
    </svg>
  );
  return (
    <div style={{ display: "flex" }}>
      <div style={{ width: 22, height: 22, borderRadius: "50%", background: "#eb001b", opacity: 0.88 }} />
      <div style={{ width: 22, height: 22, borderRadius: "50%", background: "#f79e1b", opacity: 0.88, marginLeft: -8 }} />
    </div>
  );
}

// ── Compact network badge (for lists) ─────────────────────────────────────────
function NetworkBadge({ type }: { type: CreditCard["type"] }) {
  if (type === "visa") return (
    <span style={{ fontSize: 10, fontWeight: 800, fontStyle: "italic", color: "#7b9ee8", letterSpacing: "-0.3px", fontFamily: "Roboto, sans-serif", background: "rgba(123,158,232,0.12)", padding: "2px 6px", borderRadius: 4, border: "1px solid rgba(123,158,232,0.2)" }}>VISA</span>
  );
  if (type === "amex") return (
    <span style={{ fontSize: 9, fontWeight: 700, color: "#c8a84b", letterSpacing: "0.1em", background: "rgba(200,168,75,0.12)", padding: "2px 5px", borderRadius: 4, border: "1px solid rgba(200,168,75,0.2)" }}>AMEX</span>
  );
  if (type === "rupay") return (
    <span style={{ background: "rgba(244,121,32,0.1)", padding: "2px 6px", borderRadius: 4, border: "1px solid rgba(244,121,32,0.2)", display: "inline-flex", alignItems: "center" }}>
      <svg width="14" height="14" viewBox="0 0 16 18" fill="none">
        <polygon points="0,1 8,9 0,17" fill="#f47920"/>
        <polygon points="5,1 13,9 5,17" fill="#3aaa35"/>
      </svg>
    </span>
  );
  return (
    <span style={{ display: "inline-flex", alignItems: "center", gap: 2, background: "rgba(247,158,27,0.1)", padding: "2px 5px", borderRadius: 4, border: "1px solid rgba(247,158,27,0.15)" }}>
      <span style={{ width: 9, height: 9, borderRadius: "50%", background: "#eb001b", display: "inline-block" }} />
      <span style={{ width: 9, height: 9, borderRadius: "50%", background: "#f79e1b", display: "inline-block", marginLeft: -4 }} />
    </span>
  );
}

// ── Copy button ───────────────────────────────────────────────────────────────
function CopyBtn({ value, light }: { value: string; light?: boolean }) {
  const [copied, setCopied] = useState(false);
  const { onPointerDown, Ripples } = useRipple(light ? "rgba(0,0,0,0.12)" : "rgba(208,188,255,0.25)");

  const copy = (e: React.MouseEvent) => {
    e.stopPropagation();
    navigator.clipboard.writeText(value).catch(() => {});
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const fg = light ? "rgba(0,0,0,0.5)" : M3.onSurfaceVariant;

  return (
    <button
      onPointerDown={onPointerDown}
      onClick={copy}
      className="ripple-root"
      style={{
        background: copied
          ? (light ? "rgba(110,231,183,0.22)" : "rgba(110,231,183,0.18)")
          : (light ? "rgba(0,0,0,0.08)" : "rgba(255,255,255,0.08)"),
        border: "none", borderRadius: 8,
        padding: "4px 6px", cursor: "pointer",
        display: "inline-flex", alignItems: "center", justifyContent: "center",
        marginLeft: 6, transition: "background 200ms ease",
        position: "relative", overflow: "hidden",
      }}
    >
      <Ripples />
      {copied ? (
        <svg width="12" height="12" viewBox="0 0 12 12" fill="none">
          <path d="M2 6l3 3 5-5" stroke="#6EE7B7" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/>
        </svg>
      ) : (
        <svg width="12" height="12" viewBox="0 0 12 12" fill="none">
          <rect x="4" y="1" width="7" height="8" rx="1.5" stroke={fg} strokeWidth="1.2"/>
          <rect x="1" y="3.5" width="7" height="8" rx="1.5" stroke={fg} strokeWidth="1.2" fill="none"/>
        </svg>
      )}
    </button>
  );
}

// ── Credit card visual ────────────────────────────────────────────────────────
function CreditCardView({ card, copyable }: { card: CreditCard; copyable?: boolean }) {
  const txt = card.lightText ? "rgba(0,0,0,0.75)" : "rgba(255,255,255,0.9)";
  const sub = card.lightText ? "rgba(0,0,0,0.4)" : "rgba(255,255,255,0.45)";

  return (
    <div style={{
      width: "100%", aspectRatio: "1.586",
      background: card.gradient, borderRadius: 20,
      padding: "20px 22px",
      display: "flex", flexDirection: "column", justifyContent: "space-between",
      position: "relative", overflow: "hidden",
      boxShadow: "0 8px 32px rgba(0,0,0,0.6), 0 0 0 1px rgba(255,255,255,0.06)",
    }}>
      <div style={{
        position: "absolute", top: 0, left: 0, right: 0, height: "45%",
        background: "linear-gradient(180deg,rgba(255,255,255,0.07) 0%,transparent 100%)",
        borderRadius: "20px 20px 0 0", pointerEvents: "none",
      }}/>
      {/* Header */}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", position: "relative" }}>
        <div>
          <div style={{ fontSize: 10, color: sub, letterSpacing: "0.08em", marginBottom: 2 }}>{card.name}</div>
          <div style={{ fontSize: 13, fontWeight: 500, color: txt }}>{card.holder}</div>
        </div>
        <CardLogo type={card.type} accent={card.accentColor} />
      </div>
      {/* Chip */}
      <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
        <div className="card-chip" />
        <div style={{ width: 26, height: 18, borderRadius: 12, border: `1.5px solid ${card.accentColor}30`, opacity: 0.55 }}/>
      </div>
      {/* Number */}
      <div style={{ display: "flex", alignItems: "center" }}>
        <span style={{
          fontFamily: "'Roboto Mono', monospace",
          fontSize: card.type === "amex" ? 14 : 16,
          fontWeight: 400, color: txt, letterSpacing: "0.14em",
        }}>{card.number}</span>
        {copyable && <CopyBtn value={card.number.replace(/\s/g, "")} light={card.lightText} />}
      </div>
      {/* Footer */}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end" }}>
        <div style={{ display: "flex", gap: 18 }}>
          <div>
            <div style={{ fontSize: 9, color: sub, letterSpacing: "0.1em", marginBottom: 3 }}>EXPIRES</div>
            <div style={{ display: "flex", alignItems: "center" }}>
              <span style={{ fontFamily: "'Roboto Mono', monospace", fontSize: 13, color: txt, letterSpacing: "0.1em" }}>{card.expiry}</span>
              {copyable && <CopyBtn value={card.expiry} light={card.lightText} />}
            </div>
          </div>
          <div>
            <div style={{ fontSize: 9, color: sub, letterSpacing: "0.1em", marginBottom: 3 }}>CVV</div>
            <div style={{ display: "flex", alignItems: "center" }}>
              <span style={{ fontFamily: "'Roboto Mono', monospace", fontSize: 13, color: txt, letterSpacing: "0.1em" }}>{card.cvv}</span>
              {copyable && <CopyBtn value={card.cvv} light={card.lightText} />}
            </div>
          </div>
        </div>
        <span style={{ fontSize: 9, color: sub, letterSpacing: "0.06em" }}>TAP TO PAY</span>
      </div>
    </div>
  );
}

// ── Pill selector (first sheet) ───────────────────────────────────────────────
function PillSelector({ onSelect }: { onSelect: (t: "cards" | "passwords") => void }) {
  return (
    <div style={{ padding: "12px 16px 4px", display: "flex", gap: 10 }}>
      {[
        { type: "passwords" as const, icon: "🔑", label: "Passwords", accent: "rgba(167,139,250,0.18)" },
        { type: "cards" as const,     icon: "💳", label: "Cards",     accent: "rgba(100,200,255,0.15)" },
      ].map(opt => {
        const { onPointerDown, Ripples } = useRipple("rgba(255,255,255,0.15)");
        return (
          <button
            key={opt.type}
            onPointerDown={onPointerDown}
            onClick={() => onSelect(opt.type)}
            className="ripple-root"
            style={{
              flex: 1,
              display: "flex", alignItems: "center", justifyContent: "center",
              gap: 9, padding: "15px 10px",
              background: opt.accent,
              backdropFilter: "blur(16px) saturate(160%)",
              WebkitBackdropFilter: "blur(16px) saturate(160%)",
              border: "1px solid rgba(255,255,255,0.14)",
              borderRadius: 100, cursor: "pointer",
              position: "relative", overflow: "hidden",
              boxShadow: "0 2px 12px rgba(0,0,0,0.25), inset 0 1px 0 rgba(255,255,255,0.12)",
              transition: "all 200ms cubic-bezier(0.2,0,0,1)",
            }}
            onMouseEnter={e => { (e.currentTarget as HTMLButtonElement).style.background = "rgba(255,255,255,0.14)"; }}
            onMouseLeave={e => { (e.currentTarget as HTMLButtonElement).style.background = opt.accent; }}
          >
            <Ripples />
            {/* Icon glow wrapper */}
            <div style={{
              width: 36, height: 36, borderRadius: "50%",
              background: "rgba(255,255,255,0.08)",
              border: "1px solid rgba(255,255,255,0.1)",
              display: "flex", alignItems: "center", justifyContent: "center",
              fontSize: 18, flexShrink: 0,
            }}>
              {opt.icon}
            </div>
            <span style={{ fontSize: 15, fontWeight: 500, color: "rgba(255,255,255,0.92)", fontFamily: "Roboto, sans-serif", letterSpacing: "0.01em" }}>
              {opt.label}
            </span>
          </button>
        );
      })}
    </div>
  );
}

// ── Cards list sheet ──────────────────────────────────────────────────────────
function CardsListSheet({ onSelect, onBack, cards }: { onSelect: (c: CreditCard) => void; onBack: () => void; cards: CreditCard[] }) {
  return (
    <div style={{ paddingBottom: 24 }}>
      {cards.map(card => {
        const { onPointerDown, Ripples } = useRipple();
        return (
          <button
            key={card.id}
            onPointerDown={onPointerDown}
            onClick={() => onSelect(card)}
            className="ripple-root"
            style={{
              width: "100%", display: "flex", alignItems: "center", gap: 14,
              padding: "12px 20px", background: "none", border: "none",
              cursor: "pointer", textAlign: "left", position: "relative", overflow: "hidden",
              transition: "background 150ms ease",
            }}
          >
            <Ripples />
            {/* Mini card swatch */}
            <div style={{
              width: 52, height: 33, borderRadius: 8,
              background: card.gradient, flexShrink: 0,
              border: "1px solid rgba(255,255,255,0.08)",
              display: "flex", alignItems: "center", justifyContent: "center",
            }}>
              <div className="card-chip" style={{ width: 18, height: 14 }} />
            </div>
            <div style={{ flex: 1 }}>
              <div style={{ display: "flex", alignItems: "center", gap: 7, marginBottom: 3 }}>
                <span style={{ fontSize: 14, fontWeight: 500, color: M3.onSurface }}>{card.name}</span>
                <NetworkBadge type={card.type} />
              </div>
              <div style={{ fontFamily: "'Roboto Mono', monospace", fontSize: 12, color: M3.onSurfaceVariant }}>
                •••• {card.number.slice(-4)}
              </div>
            </div>
            <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
              <path d="M6 4l5 5-5 5" stroke={M3.outline} strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
          </button>
        );
      })}
    </div>
  );
}

// ── Passwords list sheet ──────────────────────────────────────────────────────
function PasswordsListSheet({ onSelect, onBack, passwords }: { onSelect: (p: Password) => void; onBack: () => void; passwords: Password[] }) {
  return (
    <div style={{ paddingBottom: 24 }}>
      {passwords.map(pw => {
        const { onPointerDown, Ripples } = useRipple();
        return (
          <button
            key={pw.id}
            onPointerDown={onPointerDown}
            onClick={() => onSelect(pw)}
            className="ripple-root"
            style={{
              width: "100%", display: "flex", alignItems: "center", gap: 14,
              padding: "10px 20px", background: "none", border: "none",
              cursor: "pointer", textAlign: "left", position: "relative", overflow: "hidden",
            }}
          >
            <Ripples />
            <div style={{
              width: 42, height: 42, borderRadius: 12, flexShrink: 0,
              background: pw.color + "22", border: `1px solid ${pw.color}33`,
              display: "flex", alignItems: "center", justifyContent: "center",
              fontSize: 17, fontWeight: 700, color: pw.color,
              fontFamily: pw.icon.length > 1 ? "sans-serif" : "inherit",
            }}>
              {pw.icon}
            </div>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 14, fontWeight: 500, color: M3.onSurface, marginBottom: 2 }}>{pw.site}</div>
              <div style={{ fontSize: 12, color: M3.onSurfaceVariant }}>{pw.username}</div>
            </div>
            <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
              <path d="M6 4l5 5-5 5" stroke={M3.outline} strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
          </button>
        );
      })}
    </div>
  );
}

// ── Biometric dialog ──────────────────────────────────────────────────────────
function BiometricSheet({ onSuccess, onCancel }: { onSuccess: () => void; onCancel: () => void }) {
  const [phase, setPhase] = useState<"idle" | "scanning" | "verified">("idle");

  const tap = () => {
    if (phase !== "idle") return;
    setPhase("scanning");
    setTimeout(() => {
      setPhase("verified");
      setTimeout(onSuccess, 700);
    }, 1100);
  };

  const ringColor = phase === "verified" ? M3.success : phase === "scanning" ? M3.primary : M3.outlineVariant;

  return (
    <div style={{ padding: "8px 24px 36px", textAlign: "center" }}>
      <div style={{ marginBottom: 28 }}>
        <div style={{ fontSize: 16, fontWeight: 500, color: M3.onSurface, marginBottom: 6 }}>
          Verify identity
        </div>
        <div style={{ fontSize: 13, color: M3.onSurfaceVariant }}>
          Touch the fingerprint sensor to continue
        </div>
      </div>

      {/* Fingerprint button */}
      <div
        onClick={tap}
        style={{
          width: 88, height: 88, borderRadius: "50%", margin: "0 auto 24px",
          background: phase === "verified" ? `${M3.success}18` : phase === "scanning" ? `${M3.primary}14` : "rgba(255,255,255,0.06)",
          border: `2px solid ${ringColor}`,
          display: "flex", alignItems: "center", justifyContent: "center",
          cursor: "pointer", transition: "all 380ms cubic-bezier(0.2,0,0,1)",
          position: "relative", overflow: "hidden",
          boxShadow: phase === "scanning" ? `0 0 0 6px ${M3.primary}18, 0 0 0 14px ${M3.primary}08` : "none",
        }}
      >
        {/* Scan line */}
        {phase === "scanning" && (
          <div style={{
            position: "absolute", left: 0, right: 0, height: 2,
            background: `linear-gradient(90deg, transparent, ${M3.primary}, transparent)`,
            top: 0,
            animation: "scan-line 1.1s linear",
          }}/>
        )}

        {phase === "verified" ? (
          <div className="check-pop">
            <svg width="38" height="38" viewBox="0 0 38 38" fill="none">
              <circle cx="19" cy="19" r="18" stroke={M3.success} strokeWidth="1.5"/>
              <path d="M11 19l6 6 10-12" stroke={M3.success} strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
          </div>
        ) : (
          <svg width="40" height="40" viewBox="0 0 40 40" fill="none">
            <path d="M20 5C11.7 5 5 11.7 5 20" stroke={ringColor} strokeWidth="2.2" strokeLinecap="round"/>
            <path d="M35 20C35 28.3 28.3 35 20 35" stroke={ringColor} strokeWidth="2.2" strokeLinecap="round"/>
            <path d="M20 11C14 11 9 16 9 22" stroke={ringColor} strokeWidth="2.2" strokeLinecap="round"/>
            <path d="M31 20C31 26 26 31 20 31" stroke={ringColor} strokeWidth="2.2" strokeLinecap="round"/>
            <path d="M20 17.5C18 17.5 16.5 19 16.5 21C16.5 24.5 19 28 20 29.5C21 28 23.5 24.5 23.5 21C23.5 19 22 17.5 20 17.5Z" stroke={ringColor} strokeWidth="2" strokeLinecap="round"/>
          </svg>
        )}
      </div>

      <div style={{
        fontSize: 13, fontWeight: 500,
        color: phase === "verified" ? M3.success : phase === "scanning" ? M3.primary : M3.onSurfaceVariant,
        transition: "color 300ms ease", marginBottom: 20,
      }}>
        {phase === "verified" ? "Identity verified" : phase === "scanning" ? "Scanning fingerprint…" : "Tap to authenticate"}
      </div>

      {phase === "idle" && (
        <button
          onClick={onCancel}
          style={{ fontSize: 14, color: M3.primary, background: "none", border: "none", cursor: "pointer", fontFamily: "Roboto, sans-serif", fontWeight: 500, padding: "8px 16px" }}
        >
          Cancel
        </button>
      )}
    </div>
  );
}

// ── Card reveal sheet ─────────────────────────────────────────────────────────
function CardRevealSheet({ card }: { card: CreditCard }) {
  return (
    <div className="card-reveal-in" style={{ padding: "4px 16px 4px", display: "flex", flexDirection: "column", gap: 14 }}>
      <CreditCardView card={card} copyable />
    </div>
  );
}

// ── Password reveal sheet ─────────────────────────────────────────────────────
function PasswordRevealSheet({ pw }: { pw: Password }) {
  const [showPass, setShowPass] = useState(false);
  const { onPointerDown: dp2, Ripples: R2 } = useRipple();

  return (
    <div className="card-reveal-in" style={{ padding: "4px 16px 4px", display: "flex", flexDirection: "column", gap: 12 }}>
      {/* Site header */}
      <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 4 }}>
        <div style={{
          width: 44, height: 44, borderRadius: 14, flexShrink: 0,
          background: pw.color + "1E", border: `1px solid ${pw.color}30`,
          display: "flex", alignItems: "center", justifyContent: "center",
          fontSize: 20, fontWeight: 700, color: pw.color,
          fontFamily: pw.icon.length > 1 ? "sans-serif" : "inherit",
        }}>
          {pw.icon}
        </div>
        <div>
          <div style={{ fontSize: 17, fontWeight: 500, color: M3.onSurface }}>{pw.site}</div>
          <div style={{ fontSize: 12, color: M3.onSurfaceVariant, marginTop: 1 }}>Saved password</div>
        </div>
      </div>

      {/* Username field */}
      <div style={{
        background: "rgba(255,255,255,0.06)", borderRadius: 16,
        padding: "14px 16px", border: "1px solid rgba(255,255,255,0.09)",
      }}>
        <div style={{ fontSize: 11, color: M3.onSurfaceVariant, letterSpacing: "0.08em", marginBottom: 6 }}>USERNAME</div>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <span style={{ fontFamily: "'Roboto Mono', monospace", fontSize: 13, color: M3.onSurface }}>{pw.username}</span>
          <CopyBtn value={pw.username} />
        </div>
      </div>

      {/* Password field */}
      <div style={{
        background: "rgba(255,255,255,0.06)", borderRadius: 16,
        padding: "14px 16px", border: "1px solid rgba(255,255,255,0.09)",
      }}>
        <div style={{ fontSize: 11, color: M3.onSurfaceVariant, letterSpacing: "0.08em", marginBottom: 6 }}>PASSWORD</div>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 8 }}>
          <span style={{
            fontFamily: "'Roboto Mono', monospace", fontSize: 13, color: M3.onSurface,
            letterSpacing: showPass ? "0.04em" : "0.2em", flex: 1,
            overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap",
            transition: "letter-spacing 200ms ease",
          }}>
            {showPass ? pw.realPassword : "•".repeat(14)}
          </span>
          <div style={{ display: "flex", alignItems: "center", gap: 4, flexShrink: 0 }}>
            <button
              onClick={() => setShowPass(v => !v)}
              style={{ background: "rgba(255,255,255,0.08)", border: "1px solid rgba(255,255,255,0.07)", borderRadius: 8, padding: "4px 6px", cursor: "pointer", display: "flex", alignItems: "center" }}
            >
              {showPass ? (
                <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                  <path d="M2 2l12 12M7 5.3A2.2 2.2 0 0 1 10.7 9M5.6 9.4A2.2 2.2 0 0 1 5.3 7M1.5 8S4 3.5 8 3.5c.7 0 1.4.15 2 .4M14.5 8S12 12.5 8 12.5c-.7 0-1.4-.15-2-.4" stroke={M3.onSurfaceVariant} strokeWidth="1.4" strokeLinecap="round"/>
                </svg>
              ) : (
                <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                  <path d="M1.5 8S4 3.5 8 3.5 14.5 8 14.5 8 12 12.5 8 12.5 1.5 8 1.5 8Z" stroke={M3.onSurfaceVariant} strokeWidth="1.4"/>
                  <circle cx="8" cy="8" r="2" stroke={M3.onSurfaceVariant} strokeWidth="1.4"/>
                </svg>
              )}
            </button>
            <CopyBtn value={pw.realPassword} />
          </div>
        </div>
      </div>

    </div>
  );
}

// ── Shared form input ─────────────────────────────────────────────────────────
function FormField({ label, value, onChange, placeholder, type = "text", maxLength }: {
  label: string; value: string; onChange: (v: string) => void;
  placeholder?: string; type?: string; maxLength?: number;
}) {
  return (
    <div>
      <div style={{ fontSize: 11, color: M3.onSurfaceVariant, letterSpacing: "0.08em", marginBottom: 6 }}>{label}</div>
      <input
        type={type}
        value={value}
        onChange={e => onChange(e.target.value)}
        placeholder={placeholder}
        maxLength={maxLength}
        style={{
          width: "100%", padding: "12px 14px",
          background: "rgba(255,255,255,0.06)",
          border: "1px solid rgba(255,255,255,0.1)",
          borderRadius: 14, color: M3.onSurface,
          fontSize: 14, fontFamily: "Roboto, sans-serif",
          outline: "none", boxSizing: "border-box",
          transition: "border-color 180ms ease",
        }}
        onFocus={e => { e.target.style.borderColor = M3.primary + "88"; }}
        onBlur={e => { e.target.style.borderColor = "rgba(255,255,255,0.1)"; }}
      />
    </div>
  );
}

// ── Add Password form ─────────────────────────────────────────────────────────
function AddPasswordForm({ onSave }: { onSave: (p: Password) => void }) {
  const [site, setSite] = useState("");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [showPass, setShowPass] = useState(false);
  const { onPointerDown, Ripples } = useRipple();

  const iconLetter = site.trim().charAt(0).toUpperCase() || "?";
  const accentColors = ["#EA4335","#1428A0","#6E5494","#E50914","#0078D4","#00B894","#F39C12"];
  const color = accentColors[(site.charCodeAt(0) || 0) % accentColors.length];

  const canSave = site.trim() && username.trim() && password.trim();

  const save = () => {
    if (!canSave) return;
    onSave({ id: Date.now().toString(), site: site.trim(), username: username.trim(), realPassword: password, icon: iconLetter, color });
  };

  return (
    <div style={{ padding: "4px 16px 4px", display: "flex", flexDirection: "column", gap: 12 }}>
      <FormField label="SITE / APP NAME" value={site} onChange={setSite} placeholder="e.g. Twitter" />
      <FormField label="USERNAME / EMAIL" value={username} onChange={setUsername} placeholder="you@example.com" />
      <div>
        <div style={{ fontSize: 11, color: M3.onSurfaceVariant, letterSpacing: "0.08em", marginBottom: 6 }}>PASSWORD</div>
        <div style={{ position: "relative" }}>
          <input
            type={showPass ? "text" : "password"}
            value={password}
            onChange={e => setPassword(e.target.value)}
            placeholder="Enter password"
            style={{
              width: "100%", padding: "12px 44px 12px 14px",
              background: "rgba(255,255,255,0.06)",
              border: "1px solid rgba(255,255,255,0.1)",
              borderRadius: 14, color: M3.onSurface,
              fontSize: 14, fontFamily: "Roboto, sans-serif",
              outline: "none", boxSizing: "border-box",
            }}
            onFocus={e => { e.target.style.borderColor = M3.primary + "88"; }}
            onBlur={e => { e.target.style.borderColor = "rgba(255,255,255,0.1)"; }}
          />
          <button
            onClick={() => setShowPass(v => !v)}
            style={{ position: "absolute", right: 12, top: "50%", transform: "translateY(-50%)", background: "none", border: "none", cursor: "pointer", padding: 4, display: "flex", alignItems: "center" }}
          >
            {showPass
              ? <svg width="16" height="16" viewBox="0 0 16 16" fill="none"><path d="M2 2l12 12M7 5.3A2.2 2.2 0 0 1 10.7 9M5.6 9.4A2.2 2.2 0 0 1 5.3 7M1.5 8S4 3.5 8 3.5c.7 0 1.4.15 2 .4M14.5 8S12 12.5 8 12.5c-.7 0-1.4-.15-2-.4" stroke={M3.onSurfaceVariant} strokeWidth="1.4" strokeLinecap="round"/></svg>
              : <svg width="16" height="16" viewBox="0 0 16 16" fill="none"><path d="M1.5 8S4 3.5 8 3.5 14.5 8 14.5 8 12 12.5 8 12.5 1.5 8 1.5 8Z" stroke={M3.onSurfaceVariant} strokeWidth="1.4"/><circle cx="8" cy="8" r="2" stroke={M3.onSurfaceVariant} strokeWidth="1.4"/></svg>
            }
          </button>
        </div>
      </div>
      <button
        onPointerDown={onPointerDown}
        onClick={save}
        className="ripple-root"
        style={{
          marginTop: 4, padding: "14px", border: "none", borderRadius: 100,
          background: canSave ? M3.primaryContainer : "rgba(255,255,255,0.06)",
          color: canSave ? M3.onPrimaryContainer : M3.onSurfaceVariant,
          fontSize: 15, fontWeight: 500, cursor: canSave ? "pointer" : "default",
          fontFamily: "Roboto, sans-serif", position: "relative", overflow: "hidden",
          transition: "all 200ms ease",
        }}
      >
        <Ripples />
        Save Password
      </button>
    </div>
  );
}

// ── Add Card form ─────────────────────────────────────────────────────────────
function AddCardForm({ onSave }: { onSave: (c: CreditCard) => void }) {
  const [number, setNumber] = useState("");
  const [holder, setHolder] = useState("");
  const [expiry, setExpiry] = useState("");
  const [cvv, setCvv] = useState("");
  const [manualGradientIdx, setManualGradientIdx] = useState<number | null>(null);
  const [manualType, setManualType] = useState<CreditCard["type"] | null>(null);
  const { onPointerDown, Ripples } = useRipple();

  const autoType = detectCardType(number);
  const type = manualType ?? autoType;
  const formatted = formatCardNumber(number, type);
  const canSave = number.replace(/\s/g, "").length >= 15 && holder.trim() && expiry.length === 5 && cvv.length >= 3;

  const scheme = manualGradientIdx !== null ? CARD_GRADIENTS[manualGradientIdx] : CARD_GRADIENTS[0];

  const previewTextColor = scheme.light ? "rgba(0,0,0,0.7)" : "rgba(255,255,255,0.85)";
  const previewSubColor  = scheme.light ? "rgba(0,0,0,0.4)"  : "rgba(255,255,255,0.45)";

  const save = () => {
    if (!canSave) return;
    onSave({
      id: Date.now().toString(),
      name: holder.trim(),
      number: formatted,
      expiry,
      cvv,
      holder: holder.trim(),
      type,
      gradient: scheme.gradient,
      accentColor: scheme.accent,
      lightText: scheme.light,
    });
  };

  return (
    <div style={{ padding: "4px 16px 4px", display: "flex", flexDirection: "column", gap: 12 }}>
      {/* Live card preview */}
      <div>
        <div style={{
          width: "100%", aspectRatio: "1.586", background: scheme.gradient,
          borderRadius: 16, padding: "16px 18px", display: "flex", flexDirection: "column",
          justifyContent: "space-between", border: "1px solid rgba(255,255,255,0.08)",
          position: "relative", overflow: "hidden",
          transition: "background 600ms cubic-bezier(0.2,0,0,1)",
        }}>
          <div style={{ position: "absolute", top: 0, left: 0, right: 0, height: "45%", background: "linear-gradient(180deg,rgba(255,255,255,0.07) 0%,transparent 100%)", pointerEvents: "none" }}/>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", position: "relative" }}>
            <div style={{ fontSize: 12, fontWeight: 500, color: previewTextColor }}>{holder || "CARDHOLDER"}</div>
            <CardLogo type={type} accent={scheme.accent} />
          </div>
          <div className="card-chip" style={{ width: 28, height: 22 }} />
          <span style={{ fontFamily: "'Roboto Mono', monospace", fontSize: 14, color: previewTextColor, letterSpacing: "0.14em" }}>
            {formatted || "•••• •••• •••• ••••"}
          </span>
          <div style={{ display: "flex", gap: 16 }}>
            <div>
              <div style={{ fontSize: 9, color: previewSubColor, letterSpacing: "0.1em", marginBottom: 2 }}>EXPIRES</div>
              <span style={{ fontFamily: "'Roboto Mono', monospace", fontSize: 12, color: previewTextColor }}>{expiry || "MM/YY"}</span>
            </div>
            <div>
              <div style={{ fontSize: 9, color: previewSubColor, letterSpacing: "0.1em", marginBottom: 2 }}>CVV</div>
              <span style={{ fontFamily: "'Roboto Mono', monospace", fontSize: 12, color: previewTextColor }}>{cvv || "•••"}</span>
            </div>
          </div>
        </div>

        {/* Color swatches */}
        <div style={{ display: "flex", gap: 6, marginTop: 10, flexWrap: "wrap" }}>
          {CARD_GRADIENTS.map((g, i) => (
            <button key={i} onClick={() => setManualGradientIdx(i === manualGradientIdx ? null : i)} style={{
              width: 28, height: 18, borderRadius: 5, background: g.gradient,
              border: manualGradientIdx === i ? `2px solid ${M3.primary}` : "2px solid rgba(255,255,255,0.12)",
              cursor: "pointer", padding: 0, transition: "border 150ms ease",
            }}/>
          ))}
        </div>
      </div>

      <div>
        <div style={{ fontSize: 11, color: M3.onSurfaceVariant, letterSpacing: "0.08em", marginBottom: 6 }}>CARD NUMBER</div>
        <input
          value={formatted}
          onChange={e => setNumber(e.target.value.replace(/\D/g, ""))}
          placeholder="1234 5678 9012 3456"
          inputMode="numeric"
          style={{ width: "100%", padding: "12px 14px", background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 14, color: M3.onSurface, fontSize: 14, fontFamily: "'Roboto Mono', monospace", outline: "none", boxSizing: "border-box", letterSpacing: "0.08em" }}
          onFocus={e => { e.target.style.borderColor = M3.primary + "88"; }}
          onBlur={e => { e.target.style.borderColor = "rgba(255,255,255,0.1)"; }}
        />
      </div>

      {/* Network selector */}
      <div>
        <div style={{ fontSize: 11, color: M3.onSurfaceVariant, letterSpacing: "0.08em", marginBottom: 8 }}>
          NETWORK
          {!manualType && <span style={{ color: M3.primary, marginLeft: 6, fontSize: 10 }}>auto-detected</span>}
        </div>
        <div style={{ display: "flex", gap: 8 }}>
          {([
            { id: "visa" as const, label: "Visa" },
            { id: "mastercard" as const, label: "MC" },
            { id: "amex" as const, label: "Amex" },
            { id: "rupay" as const, label: "RuPay" },
          ]).map(net => {
            const isActive = type === net.id;
            return (
              <button
                key={net.id}
                onClick={() => setManualType(manualType === net.id ? null : net.id)}
                style={{
                  flex: 1, padding: "10px 4px",
                  background: isActive ? "rgba(208,188,255,0.15)" : "rgba(255,255,255,0.04)",
                  border: isActive ? `1.5px solid ${M3.primary}88` : "1.5px solid rgba(255,255,255,0.08)",
                  borderRadius: 14, cursor: "pointer",
                  display: "flex", flexDirection: "column", alignItems: "center", gap: 6,
                  transition: "all 180ms ease",
                }}
              >
                <NetworkBadge type={net.id} />
                <span style={{ fontSize: 10, color: isActive ? M3.primary : M3.onSurfaceVariant, fontFamily: "Roboto, sans-serif" }}>
                  {net.label}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      <FormField label="CARDHOLDER NAME" value={holder} onChange={setHolder} placeholder="As it appears on the card" />
      <div style={{ display: "flex", gap: 10 }}>
        <div style={{ flex: 1 }}>
          <div style={{ fontSize: 11, color: M3.onSurfaceVariant, letterSpacing: "0.08em", marginBottom: 6 }}>EXPIRY</div>
          <input
            value={expiry}
            onChange={e => setExpiry(formatExpiry(e.target.value))}
            placeholder="MM/YY"
            inputMode="numeric"
            maxLength={5}
            style={{ width: "100%", padding: "12px 14px", background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 14, color: M3.onSurface, fontSize: 14, fontFamily: "'Roboto Mono', monospace", outline: "none", boxSizing: "border-box" }}
            onFocus={e => { e.target.style.borderColor = M3.primary + "88"; }}
            onBlur={e => { e.target.style.borderColor = "rgba(255,255,255,0.1)"; }}
          />
        </div>
        <div style={{ flex: 1 }}>
          <div style={{ fontSize: 11, color: M3.onSurfaceVariant, letterSpacing: "0.08em", marginBottom: 6 }}>CVV</div>
          <input
            value={cvv}
            onChange={e => setCvv(e.target.value.replace(/\D/g, "").slice(0, type === "amex" ? 4 : 3))}
            placeholder={type === "amex" ? "4 digits" : "3 digits"}
            inputMode="numeric"
            type="password"
            style={{ width: "100%", padding: "12px 14px", background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 14, color: M3.onSurface, fontSize: 14, fontFamily: "'Roboto Mono', monospace", outline: "none", boxSizing: "border-box" }}
            onFocus={e => { e.target.style.borderColor = M3.primary + "88"; }}
            onBlur={e => { e.target.style.borderColor = "rgba(255,255,255,0.1)"; }}
          />
        </div>
      </div>
      <button
        onPointerDown={onPointerDown}
        onClick={save}
        className="ripple-root"
        style={{
          marginTop: 4, padding: "14px", border: "none", borderRadius: 100,
          background: canSave ? M3.primaryContainer : "rgba(255,255,255,0.06)",
          color: canSave ? M3.onPrimaryContainer : M3.onSurfaceVariant,
          fontSize: 15, fontWeight: 500, cursor: canSave ? "pointer" : "default",
          fontFamily: "Roboto, sans-serif", position: "relative", overflow: "hidden",
          transition: "all 200ms ease",
        }}
      >
        <Ripples />
        Save Card
      </button>
    </div>
  );
}

// ── Main vault UI ─────────────────────────────────────────────────────────────
function PasswordRow({ pw }: { pw: Password }) {
  const { onPointerDown, Ripples } = useRipple();
  return (
    <button
      onPointerDown={onPointerDown}
      className="ripple-root"
      style={{
        width: "100%", display: "flex", alignItems: "center", gap: 14,
        padding: "10px 20px", background: "none", border: "none",
        cursor: "pointer", textAlign: "left", position: "relative", overflow: "hidden",
      }}
    >
      <Ripples />
      <div style={{
        width: 44, height: 44, borderRadius: 14, flexShrink: 0,
        background: pw.color + "1E", border: `1px solid ${pw.color}28`,
        display: "flex", alignItems: "center", justifyContent: "center",
        fontSize: 18, fontWeight: 700, color: pw.color,
        fontFamily: pw.icon.length > 1 ? "sans-serif" : "inherit",
      }}>
        {pw.icon}
      </div>
      <div style={{ flex: 1 }}>
        <div style={{ fontSize: 14, fontWeight: 400, color: M3.onSurface, marginBottom: 2 }}>{pw.site}</div>
        <div style={{ fontSize: 12, color: M3.onSurfaceVariant }}>{pw.username}</div>
      </div>
      <div style={{ fontFamily: "'Roboto Mono', monospace", fontSize: 12, color: M3.outline, letterSpacing: "0.2em" }}>••••••</div>
    </button>
  );
}

function VaultContent({ tab, cards, passwords }: { tab: "passwords" | "cards" | "settings"; cards: CreditCard[]; passwords: Password[] }) {
  if (tab === "cards") return (
    <div style={{ flex: 1, overflowY: "auto", padding: "8px 0" }}>
      <div style={{ padding: "0 20px 16px", fontSize: 22, fontWeight: 400, color: M3.onSurface }}>
        Saved Cards
      </div>
      {cards.map(card => (
        <div key={card.id} style={{ padding: "8px 20px 4px" }}>
          <CreditCardView card={card} />
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "8px 4px 4px" }}>
            <div style={{ display: "flex", alignItems: "center", gap: 7 }}>
              <span style={{ fontSize: 13, fontWeight: 500, color: M3.onSurface }}>{card.name}</span>
              <NetworkBadge type={card.type} />
            </div>
            <span style={{ fontFamily: "'Roboto Mono', monospace", fontSize: 12, color: M3.onSurfaceVariant }}>•••• {card.number.slice(-4)}</span>
          </div>
        </div>
      ))}
      <div style={{ height: 16 }}/>
    </div>
  );

  if (tab === "settings") return (
    <div style={{ flex: 1, padding: "8px 0" }}>
      {[
        { label: "Biometric unlock", sub: "Use fingerprint to access vault" },
        { label: "Auto-fill service", sub: "Enabled for all apps" },
        { label: "Shake sensitivity", sub: "Medium" },
        { label: "Sync & backup", sub: "Google Drive · Last synced now" },
        { label: "App lock timeout", sub: "5 minutes" },
      ].map(item => (
        <div key={item.label} style={{ padding: "14px 20px", display: "flex", alignItems: "center", justifyContent: "space-between", borderBottom: `1px solid ${M3.outlineVariant}22` }}>
          <div>
            <div style={{ fontSize: 14, fontWeight: 400, color: M3.onSurface }}>{item.label}</div>
            <div style={{ fontSize: 12, color: M3.onSurfaceVariant, marginTop: 2 }}>{item.sub}</div>
          </div>
          <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
            <path d="M6 4l5 5-5 5" stroke={M3.outline} strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
        </div>
      ))}
    </div>
  );

  // Passwords tab (default)
  return (
    <div style={{ flex: 1, overflowY: "auto" }}>
      {/* Search */}
      <div style={{ padding: "8px 20px 12px" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 12, background: M3.surfaceContainerHighest, borderRadius: 28, padding: "10px 18px" }}>
          <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
            <circle cx="8" cy="8" r="5.5" stroke={M3.onSurfaceVariant} strokeWidth="1.5"/>
            <path d="M12.5 12.5l3 3" stroke={M3.onSurfaceVariant} strokeWidth="1.5" strokeLinecap="round"/>
          </svg>
          <span style={{ fontSize: 14, color: M3.onSurfaceVariant }}>Search passwords…</span>
        </div>
      </div>
      {/* Recent section */}
      <div style={{ padding: "4px 20px 8px", fontSize: 12, fontWeight: 500, color: M3.onSurfaceVariant, letterSpacing: "0.06em" }}>RECENT</div>
      {passwords.map(pw => (
        <PasswordRow key={pw.id} pw={pw} />
      ))}
    </div>
  );
}

// ── Onboarding / Permission Setup Screen ─────────────────────────────────────
function SetupScreen({ onDone }: { onDone: () => void }) {
  const [serviceRunning, setServiceRunning] = useState(
    () => !!(window as unknown as Record<string, unknown>).__KEYVAULT_SERVICE_RUNNING__
  );

  // Poll for service status injected by native MainActivity
  useEffect(() => {
    const iv = setInterval(() => {
      const running = !!(window as unknown as Record<string, unknown>).__KEYVAULT_SERVICE_RUNNING__;
      setServiceRunning(running);
      if (running) clearInterval(iv);
    }, 800);
    return () => clearInterval(iv);
  }, []);

  return (
    <div style={{ width: "100%", height: "100%", background: M3.bg, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", padding: "32px 24px", fontFamily: "Roboto, sans-serif", boxSizing: "border-box" }}>
      <div style={{ width: 80, height: 80, borderRadius: 24, background: M3.primaryContainer, display: "flex", alignItems: "center", justifyContent: "center", marginBottom: 28 }}>
        <svg width="40" height="40" viewBox="0 0 40 40" fill="none">
          <path d="M20 4a6 6 0 0 0-6 6v3H11a3 3 0 0 0-3 3v18a3 3 0 0 0 3 3h18a3 3 0 0 0 3-3V16a3 3 0 0 0-3-3h-3v-3a6 6 0 0 0-6-6z" stroke={M3.onPrimaryContainer} strokeWidth="2.5" strokeLinejoin="round"/>
          <circle cx="20" cy="23" r="2.5" fill={M3.onPrimaryContainer}/>
          <path d="M20 25.5v3.5" stroke={M3.onPrimaryContainer} strokeWidth="2.5" strokeLinecap="round"/>
        </svg>
      </div>

      <div style={{ fontSize: 24, fontWeight: 400, color: M3.onSurface, marginBottom: 8, textAlign: "center" }}>
        {serviceRunning ? "All set!" : "Setting up…"}
      </div>
      <div style={{ fontSize: 14, color: M3.onSurfaceVariant, textAlign: "center", lineHeight: 1.6, marginBottom: 40 }}>
        {serviceRunning
          ? "Shake detection is active. Close this app and shake your phone from anywhere."
          : "Follow the system prompts that just appeared.\nGrant both permissions to enable shake autofill."}
      </div>

      <div style={{ width: "100%", display: "flex", flexDirection: "column", gap: 12, marginBottom: 36 }}>
        {[
          { label: "Display over other apps", sub: "Lets popup appear on any screen" },
          { label: "Battery optimization off", sub: "Keeps service alive in background" },
        ].map((item, i) => (
          <div key={i} style={{ background: M3.surfaceContainer, borderRadius: 16, padding: "16px 18px", display: "flex", alignItems: "center", gap: 14 }}>
            <div style={{ width: 36, height: 36, borderRadius: "50%", background: serviceRunning ? "#1a4a2e" : M3.surfaceContainerHighest, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0, transition: "background 400ms ease" }}>
              {serviceRunning
                ? <svg width="18" height="18" viewBox="0 0 18 18" fill="none"><path d="M4 9l4 4 6-7" stroke="#6ee7b7" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/></svg>
                : <div style={{ width: 16, height: 16, borderRadius: "50%", border: `2px solid ${M3.outline}`, borderTopColor: M3.primary, animation: "spin 1s linear infinite" }}/>
              }
            </div>
            <div>
              <div style={{ fontSize: 14, fontWeight: 500, color: M3.onSurface }}>{item.label}</div>
              <div style={{ fontSize: 12, color: M3.onSurfaceVariant, marginTop: 2 }}>{item.sub}</div>
            </div>
          </div>
        ))}
      </div>

      <button
        onClick={serviceRunning ? onDone : undefined}
        style={{
          width: "100%", padding: "16px",
          background: serviceRunning ? M3.primaryContainer : "rgba(255,255,255,0.06)",
          color: serviceRunning ? M3.onPrimaryContainer : M3.onSurfaceVariant,
          border: "none", borderRadius: 28, fontSize: 16, fontWeight: 500,
          cursor: serviceRunning ? "pointer" : "default",
          fontFamily: "Roboto, sans-serif", transition: "all 400ms ease",
        }}
      >
        {serviceRunning ? "Open KeyVault →" : "Waiting for permissions…"}
      </button>
    </div>
  );
}

// ── Root App ──────────────────────────────────────────────────────────────────
export default function App() {
  const [activeTab, setActiveTab] = useState<"passwords" | "cards" | "settings">("passwords");
  const [screen, setScreen] = useState<Screen>("idle");
  const [selectedCard, setSelectedCard] = useState<CreditCard | null>(null);
  const [selectedPassword, setSelectedPassword] = useState<Password | null>(null);
  const [showType, setShowType] = useState<"cards" | "passwords" | null>(null);
  const [fabShaking, setFabShaking] = useState(false);
  const [cards, setCards] = useState<CreditCard[]>(INIT_CARDS);
  const [passwords, setPasswords] = useState<Password[]>(INIT_PASSWORDS);
  const [addOpen, setAddOpen] = useState<"card" | "password" | null>(null);
  const [setupDone, setSetupDone] = useState(() => localStorage.getItem("kv_setup") === "1");

  const triggerShake = useCallback(() => {
    setFabShaking(true);
    setTimeout(() => { setFabShaking(false); setScreen("pill-options"); }, 480);
  }, []);

  // Real device shake detection via accelerometer
  useEffect(() => {
    let lastX = 0, lastY = 0, lastZ = 0;
    let lastTime = 0;
    let cooldown = false;

    const handleMotion = (e: DeviceMotionEvent) => {
      const acc = e.accelerationIncludingGravity;
      if (!acc) return;
      const now = Date.now();
      if (now - lastTime < 100) return;

      const dx = Math.abs((acc.x ?? 0) - lastX);
      const dy = Math.abs((acc.y ?? 0) - lastY);
      const dz = Math.abs((acc.z ?? 0) - lastZ);
      lastX = acc.x ?? 0; lastY = acc.y ?? 0; lastZ = acc.z ?? 0;
      lastTime = now;

      if ((dx + dy + dz) > 28 && !cooldown) {
        cooldown = true;
        setTimeout(() => { cooldown = false; }, 1500);
        triggerShake();
      }
    };

    // Listen for native bridge shake event (from ShakeService overlay)
    const handleNativeShake = () => triggerShake();
    window.addEventListener("keyvault-shake", handleNativeShake);

    // If running as overlay, auto-open immediately
    if ((window as unknown as Record<string, unknown>).__KEYVAULT_OVERLAY__) {
      setTimeout(triggerShake, 300);
    }

    // iOS 13+ requires permission
    const setup = async () => {
      if (typeof (DeviceMotionEvent as unknown as { requestPermission?: () => Promise<string> }).requestPermission === "function") {
        try {
          const permission = await (DeviceMotionEvent as unknown as { requestPermission: () => Promise<string> }).requestPermission();
          if (permission === "granted") window.addEventListener("devicemotion", handleMotion);
        } catch {}
      } else {
        window.addEventListener("devicemotion", handleMotion);
      }
    };
    setup();
    return () => {
      window.removeEventListener("devicemotion", handleMotion);
      window.removeEventListener("keyvault-shake", handleNativeShake);
    };
  }, [triggerShake]);

  const dismiss = useCallback(() => {
    setScreen("idle");
    setSelectedCard(null);
    setSelectedPassword(null);
    setShowType(null);
  }, []);

  const handleSelect = (type: "cards" | "passwords") => {
    setShowType(type);
    setScreen(type === "cards" ? "cards-list" : "passwords-list");
  };

  const handleCardSelect = (c: CreditCard) => { setSelectedCard(c); setScreen("fingerprint"); };
  const handlePasswordSelect = (p: Password) => { setSelectedPassword(p); setScreen("fingerprint"); };
  const handleFingerprint = () => setScreen(showType === "passwords" ? "password-reveal" : "card-reveal");

  const { onPointerDown: fabDown, Ripples: FabRipples } = useRipple("rgba(208,188,255,0.3)");
  const { onPointerDown: plusDown, Ripples: PlusRipples } = useRipple("rgba(208,188,255,0.3)");

  if (!setupDone) {
    return (
      <SetupScreen onDone={() => {
        localStorage.setItem("kv_setup", "1");
        setSetupDone(true);
      }} />
    );
  }

  return (
    <div style={{ width: "100%", height: "100%", background: M3.bg, display: "flex", flexDirection: "column", position: "relative", fontFamily: "Roboto, sans-serif", overflow: "hidden" }}>
      <StatusBar />

      {/* App bar */}
      <div style={{ padding: "8px 20px 12px", display: "flex", alignItems: "center", justifyContent: "space-between", flexShrink: 0, background: M3.bg }}>
        <div>
          <div style={{ fontSize: 26, fontWeight: 300, color: M3.onSurface, letterSpacing: "-0.2px" }}>
            {activeTab === "passwords" ? "Passwords" : activeTab === "cards" ? "Cards" : "Settings"}
          </div>
        </div>
        <div style={{ width: 40, height: 40, borderRadius: "50%", background: M3.primaryContainer, display: "flex", alignItems: "center", justifyContent: "center" }}>
          <svg width="22" height="22" viewBox="0 0 22 22" fill="none">
            <circle cx="11" cy="8" r="3.5" stroke={M3.onPrimaryContainer} strokeWidth="1.5"/>
            <path d="M3.5 19c0-4.14 3.36-7.5 7.5-7.5s7.5 3.36 7.5 7.5" stroke={M3.onPrimaryContainer} strokeWidth="1.5" strokeLinecap="round"/>
          </svg>
        </div>
      </div>

      {/* Main content */}
      <div style={{ flex: 1, overflow: "hidden", display: "flex", flexDirection: "column" }}>
        <VaultContent tab={activeTab} cards={cards} passwords={passwords} />
      </div>

      {/* FABs */}
      <div style={{ position: "absolute", right: 16, bottom: 90, zIndex: 10, display: "flex", flexDirection: "column", alignItems: "flex-end", gap: 12 }}>
        {/* + Add button — only on passwords/cards tabs */}
        {activeTab !== "settings" && (
          <button
            onPointerDown={plusDown}
            onClick={() => setAddOpen(activeTab === "cards" ? "card" : "password")}
            className="ripple-root"
            style={{
              width: 48, height: 48,
              background: "rgba(255,255,255,0.08)",
              backdropFilter: "blur(20px)",
              WebkitBackdropFilter: "blur(20px)",
              border: "1px solid rgba(255,255,255,0.12)",
              borderRadius: "50%", cursor: "pointer",
              display: "flex", alignItems: "center", justifyContent: "center",
              position: "relative", overflow: "hidden",
              boxShadow: "0 2px 10px rgba(0,0,0,0.3)",
            }}
          >
            <PlusRipples />
            <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
              <path d="M10 4v12M4 10h12" stroke={M3.primary} strokeWidth="2" strokeLinecap="round"/>
            </svg>
          </button>
        )}
        {/* Autofill extended FAB */}
        <button
          onPointerDown={fabDown}
          onClick={async () => {
            // Request iOS motion permission on first tap
            if (typeof (DeviceMotionEvent as unknown as { requestPermission?: () => Promise<string> }).requestPermission === "function") {
              try { await (DeviceMotionEvent as unknown as { requestPermission: () => Promise<string> }).requestPermission(); } catch {}
            }
            triggerShake();
          }}
          className={`ripple-root ${fabShaking ? "shake" : ""}`}
          style={{
            display: "flex", alignItems: "center", gap: 10,
            padding: "16px 20px",
            background: M3.primaryContainer,
            border: "none", borderRadius: 100,
            cursor: "pointer", position: "relative", overflow: "hidden",
            boxShadow: "0 3px 12px rgba(0,0,0,0.4), 0 1px 3px rgba(0,0,0,0.3)",
            transition: "box-shadow 200ms ease",
          }}
        >
          <FabRipples />
          <svg width="22" height="22" viewBox="0 0 22 22" fill="none">
            <path d="M11 2a2 2 0 0 0-2 2v1H7a2 2 0 0 0-2 2v11a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V7a2 2 0 0 0-2-2h-2V4a2 2 0 0 0-2-2Z" stroke={M3.onPrimaryContainer} strokeWidth="1.5"/>
            <path d="M8 12.5l2 2 4-4" stroke={M3.onPrimaryContainer} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
          <span style={{ fontSize: 15, fontWeight: 500, color: M3.onPrimaryContainer }}>Autofill</span>
        </button>
      </div>

      {/* Bottom navigation */}
      <BottomNav active={activeTab} onChange={setActiveTab} />
      <GestureBar />

      {/* ── Bottom sheets ── */}

      {/* 1 — Pill selector */}
      <TopOverlay open={screen === "pill-options"} onDismiss={dismiss} label="Autofill with…">
        <PillSelector onSelect={handleSelect} />
      </TopOverlay>

      {/* 2a — Cards list */}
      <TopOverlay open={screen === "cards-list"} onDismiss={dismiss} onBack={() => setScreen("pill-options")} label="Choose a card">
        <CardsListSheet onSelect={handleCardSelect} onBack={() => setScreen("pill-options")} cards={cards} />
      </TopOverlay>

      {/* 2b — Passwords list */}
      <TopOverlay open={screen === "passwords-list"} onDismiss={dismiss} onBack={() => setScreen("pill-options")} label="Choose a password">
        <PasswordsListSheet onSelect={handlePasswordSelect} onBack={() => setScreen("pill-options")} passwords={passwords} />
      </TopOverlay>

      {/* 3 — Fingerprint */}
      <TopOverlay open={screen === "fingerprint"} onDismiss={dismiss}>
        <BiometricSheet onSuccess={handleFingerprint} onCancel={dismiss} />
      </TopOverlay>

      {/* 4a — Card reveal */}
      <TopOverlay open={screen === "card-reveal"} onDismiss={dismiss}>
        {selectedCard && <CardRevealSheet card={selectedCard} />}
      </TopOverlay>

      {/* 4b — Password reveal */}
      <TopOverlay open={screen === "password-reveal"} onDismiss={dismiss}>
        {selectedPassword && <PasswordRevealSheet pw={selectedPassword} />}
      </TopOverlay>

      {/* Add password */}
      <TopOverlay open={addOpen === "password"} onDismiss={() => setAddOpen(null)} label="New Password">
        <AddPasswordForm onSave={pw => { setPasswords(p => [...p, pw]); setAddOpen(null); }} />
      </TopOverlay>

      {/* Add card */}
      <TopOverlay open={addOpen === "card"} onDismiss={() => setAddOpen(null)} label="New Card">
        <AddCardForm onSave={c => { setCards(p => [...p, c]); setAddOpen(null); }} />
      </TopOverlay>
    </div>
  );
}
