import { registerPlugin } from '@capacitor/core';

export interface ShakePluginInterface {
  checkOverlayPermission(): Promise<{ granted: boolean }>;
  requestOverlayPermission(): Promise<{ opened: boolean }>;
  startShakeService(): Promise<{ started: boolean }>;
  isServiceRunning(): Promise<{ running: boolean }>;
  requestBatteryOptimizationExemption(): Promise<void>;
}

const ShakePlugin = registerPlugin<ShakePluginInterface>('ShakePlugin', {
  web: {
    checkOverlayPermission: async () => ({ granted: true }),
    requestOverlayPermission: async () => ({ opened: false }),
    startShakeService: async () => ({ started: false }),
    isServiceRunning: async () => ({ running: false }),
    requestBatteryOptimizationExemption: async () => {},
  },
});

export default ShakePlugin;
